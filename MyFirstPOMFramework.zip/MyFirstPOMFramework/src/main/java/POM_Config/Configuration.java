package POM_Config;

public class Configuration
{

   public static final String username = "//*[@name='userName']";
   public static final String password = "//*[@name='password']";
   
   public static final String tripType = "//input[@value='oneway']";
   
}
